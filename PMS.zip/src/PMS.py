from configparser import ConfigParser
from pathlib import Path
from random import randint
import time
import json
from azure.iot.device.provisioning.provisioning_device_client import ProvisioningDeviceClient
from azure.iot.device.iothub.sync_clients import IoTHubDeviceClient


# AZURE CONFIGURATION
HOST      = ""
DEVICE_ID = ""
SCOPE_ID  = ""
KEY       = ""
# SENSOR DATA PATH
TEMPERATURE     = ""
TURBIDITY       = ""
PH              = ""
AIR_TEMPERATURE = ""
HUMIDITY        = ""
CO2             = ""
DUST1           = ""
DUST2           = ""
DUST10          = ""
CO_M            = ""
HIGH_OZON       = ""
LOW_OZON        = ""




def load_configuration(filename='PMS.ini'):
    config_handler = ConfigParser()
    config_handler.read(filename)
    global HOST,DEVICE_ID,SCOPE_ID,KEY
    global TEMPERATURE,TURBIDITY,PH,AIR_TEMPERATURE
    global HUMIDITY,CO2,DUST1,DUST2,DUST10,CO_M,HIGH_OZON,LOW_OZON
    
    HOST=config_handler['AZURE_CONFIG']['HOST']
    DEVICE_ID=config_handler['AZURE_CONFIG']['DEVICE_ID']
    SCOPE_ID=config_handler['AZURE_CONFIG']['SCOPE_ID']
    KEY=config_handler['AZURE_CONFIG']['KEY']
    
    TEMPERATURE     = config_handler['SENSOR_DATA']['TEMPERATURE_PATH']
    TURBIDITY       = config_handler['SENSOR_DATA']['TURBIDITY_PATH']
    PH              = config_handler['SENSOR_DATA']['PH_PATH']
    AIR_TEMPERATURE = config_handler['SENSOR_DATA']['AIR_TEMPERATURE_PATH']
    HUMIDITY        = config_handler['SENSOR_DATA']['HUMIDITY_PATH']
    CO2             = config_handler['SENSOR_DATA']['CO2_PATH']
    DUST1           = config_handler['SENSOR_DATA']['DUST1_PATH']
    DUST2           = config_handler['SENSOR_DATA']['DUST2_PATH']
    DUST10          = config_handler['SENSOR_DATA']['DUST10_PATH']
    CO_M            = config_handler['SENSOR_DATA']['CO_M_PATH']
    HIGH_OZON       = config_handler['SENSOR_DATA']['HIGH_OZON_PATH']
    LOW_OZON        = config_handler['SENSOR_DATA']['LOW_OZON_PATH']


def load_sensor_data():
    sensor_data = dict()
    sensor_data['temp']      = Path(TEMPERATURE).read_text().strip()
    sensor_data['Turbidity'] = Path(TURBIDITY).read_text().strip()
    sensor_data['PH']        = Path(PH).read_text().strip()
    sensor_data['AirTemp']   = Path(AIR_TEMPERATURE).read_text().strip() 
    sensor_data['Humidity']  = Path(HUMIDITY).read_text().strip()
    sensor_data['CO2']       = Path(CO2).read_text().strip()
    sensor_data['Dust1']     = Path(DUST1).read_text().strip()
    sensor_data['Dust2']     = Path(DUST2).read_text().strip() 
    sensor_data['Dust10']    = Path(DUST10).read_text().strip()
    sensor_data['CO']        = Path(CO_M).read_text().strip()
    sensor_data['HighOzone'] = Path(HIGH_OZON).read_text().strip()
    sensor_data['LowOzone']  = Path(LOW_OZON).read_text().strip() 
    sensor_data['accelerometerZ'] =  str(randint(1, 4))
    
    return sensor_data
    
def device_provision():      
    provisioning_device_client = ProvisioningDeviceClient.create_from_symmetric_key(
        provisioning_host=HOST,
        registration_id=DEVICE_ID,
        id_scope=SCOPE_ID,
        symmetric_key=KEY,
    )
    return provisioning_device_client.register()

if __name__ == '__main__':
    load_configuration()
    provision_result = device_provision()
    if provision_result.status == "assigned":
        while True:
            data = load_sensor_data()
            device_handler = IoTHubDeviceClient.create_from_symmetric_key(
            symmetric_key=KEY,
            hostname=provision_result.registration_state.assigned_hub,
            device_id=provision_result.registration_state.device_id,
            product_info=None,)
            try:
               device_handler.connect()
               device_handler.send_message(json.dumps(data))
               print("SENSOR DATA SENT")
               print(json.dumps(data))
               time.sleep(2)
               device_handler.disconnect()
               time.sleep(10)
            except Exception as e:
                print(e)
                continue
    else:
        print("Error: could not provision device")





    
